"""
Jupyterlite Pyodide Tampermonkey(GM) API

"""
import logging
import asyncio
import uuid

import js
from pyodide.ffi import create_proxy, to_js, JsProxy

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

class XMLHttpRequestError(Exception):
    pass


def might_need_conversion(obj):
    """Immutable types like int and str get implicitly converted but mutable types don't.
    Handle either here.
    """
    return obj.to_py() if isinstance(obj, JsProxy) else obj


def xmlHttpRequest(**kwargs):
    """https://www.tampermonkey.net/documentation.php?locale=en#api:GM_xmlhttpRequest

    """
    future = asyncio.Future()
    request_id = uuid.uuid4()
    request_message = {"type": "GM_xmlHttpRequest request", "id": str(request_id), "value": {"payload": kwargs}}
    js_proxy = to_js(request_message, dict_converter=js.Object.fromEntries)
    js.postMessage(js_proxy)

    def on_message(event):
        logging.debug("on_message event: %s", event)
        logging.debug("on_message event.data: %s", event.data)
        logging.debug("on_message event.data.type: %s", event.data.type)
        if event.data.type == 'GM_xmlHttpRequest response' and event.data.id == str(request_id):
            js.removeEventListener('message', on_message_proxy)
            on_message_proxy.destroy()
            response = might_need_conversion(event.data.value.payload)
            future.set_result(response)
        elif event.data.type == 'GM_xmlHttpRequest error' and event.data.id == str(request_id):
            js.removeEventListener('message', on_message_proxy)
            on_message_proxy.destroy()
            exc = XMLHttpRequestError(might_need_conversion(event.data.value.payload))
            future.set_exception(exc)

    on_message_proxy = create_proxy(on_message)
    js.addEventListener('message', on_message_proxy)
    return future
